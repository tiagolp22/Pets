<ul class="hidden lg:flex lg:gap-x-24">
    <li><a href="{{ route('produit.index')}}" class="hover:text-orange-500 text-2xl">Produits</a></li>
    <li><a href="{{ route('service.index')}}" class="hover:text-orange-500 text-2xl">Services</a></li>
    <li><a href="{{ route('quisomme')}}" class="hover:text-orange-500 text-2xl">Qui sommes-nous</a></li>
</ul>
