<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Produit;

abstract class Controller
{
    public function index(Request $request)
    {
        //
    }
}
