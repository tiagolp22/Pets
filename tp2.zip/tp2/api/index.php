<?php
// Redirige Vercel vers le point d'accès index.php
require __DIR__ . '/../public/index.php';
