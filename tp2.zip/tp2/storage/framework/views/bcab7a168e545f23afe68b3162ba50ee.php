<div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
'alert absolute z-10 top-0 w-full flex justify-center items-center bg-blue-500',
'bg-red-500'=>$type=='danger',
'bg-amber-500' =>$type == 'warning',
'bg-green-500' =>$type == 'success',
]); ?>">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Cadriciel\41b-projetlaravel-tiagolp22\Pets-Racoes\resources\views/components/alert.blade.php ENDPATH**/ ?>