SERVICE
<?php /**PATH C:\xampp\htdocs\Cadriciel\41b-projetlaravel-tiagolp22\resto\resources\views/services.blade.php ENDPATH**/ ?>