<?php $__env->startSection('title', 'INDEX'); ?>

<?php $__env->startSection('content'); ?>


    <main>

        <div class="relative overflow-hidden bg-gray-900 py-32 sm:py-40 lg:p-32">

            <img src="<?php echo e(Vite::asset('resources/img/index.png')); ?>" alt="banner"
                class="absolute inset-0 z-0 h-full w-full object-cover object-right md:object-center opacity-55">
            
            <div class="mx-auto max-w-7xl px-6 lg:px-8 relative z-10">
                <div class="mx-auto max-w-2xl lg:mx-0 my-4">
                    <h1 class="text-4xl font-bold tracking-tight sm:text-6xl text-white">Pet's Rações</h1>
                    <p class="mt-6 text-lg leading-8 tracking-wide font-bold banner text-white md:text-white">
                        Livraison express garantie : achetez tout ce dont vous
                        avez
                        besoin pour votre animal de compagnie en toute sécurité et commodité aux meilleurs prix dans la
                        région métropolitaine de Recife ! Livraison dans les 2 heures par WhatsApp.</p>
                </div>
                <div class="flex flex-row space-x-4">
                    <a href="#"
                        class="bg-yellow-400 text-gray-900 hover:bg-yellow-300 py-2 px-6 rounded-full text-lg font-semibold transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg">Chien</a>
                    <a href="#"
                        class="bg-yellow-400 text-gray-900 hover:bg-yellow-300 py-2 px-6 rounded-full text-lg font-semibold transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg">Chat</a>
                    <a href="#"
                        class="bg-yellow-400 text-gray-900 hover:bg-yellow-300 py-2 px-6 rounded-full text-lg font-semibold transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg">Autres
                        petits amis à patte</a>
                </div>
            </div>
        </div>

        <section class="py-8 lg:px-40">
            <div class="container mx-auto">
                <h2 class="text-2xl font-semibold mb-4">Découvrez les marques préférées des animaux du quartier</h2>
                <div class="grid grid-cols-6 md:grid-cols-6 gap-4">

                    <div class="flex items-center justify-center">

                        <img src="<?php echo e(Vite::asset('resources/img/Logo_Formula.webp')); ?>" alt="" class="h-64">
                    </div>
                    <div class="flex items-center justify-center">
                        <img src="<?php echo e(Vite::asset('resources/img/Logo_Golden.webp')); ?>" alt="" class="h-64">
                    </div>
                    <div class="flex items-center justify-center">
                        <img src="<?php echo e(Vite::asset('resources/img/logo-pro-plan.png')); ?>" alt=""
                            class="h-28 filter grayscale">
                    </div>
                    <div class="flex items-center justify-center">
                        <img src="<?php echo e(Vite::asset('resources/img/Logo_Royal_Canin@2x.webp')); ?>" alt=""
                            class="h-64">
                    </div>
                    <div class="flex items-center justify-center">
                        <img src="<?php echo e(Vite::asset('resources/img/logo-guabi-natural.svg')); ?>" alt=""
                            class="h-32 filter grayscale">
                    </div>
                    <div class="flex items-center justify-center">
                        <img src="<?php echo e(Vite::asset('resources/img/logo-origens.jpeg')); ?>" alt=""
                            class="h-40 filter grayscale">
                    </div>

                </div>
            </div>
        </section>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cadriciel\41b-projetlaravel-tiagolp22\Pets-Racoes\resources\views/create.blade.php ENDPATH**/ ?>