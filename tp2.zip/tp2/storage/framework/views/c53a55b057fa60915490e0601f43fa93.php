<ul class="hidden lg:flex lg:gap-x-24">
    <li><a href="<?php echo e(route('produit.index')); ?>" class="hover:text-orange-500 text-2xl">Produits</a></li>
    <li><a href="<?php echo e(route('service.index')); ?>" class="hover:text-orange-500 text-2xl">Services</a></li>
    <li><a href="<?php echo e(route('quisomme')); ?>" class="hover:text-orange-500 text-2xl">Qui sommes-nous</a></li>
</ul>
<?php /**PATH C:\xampp\htdocs\Cadriciel\41b-projetlaravel-tiagolp22\Pets-Racoes\resources\views/partials/nav.blade.php ENDPATH**/ ?>