<ul class="hidden lg:flex lg:gap-x-12">
    <li><a href="<?php echo e(route('produits')); ?>" class="hover:text-gray-300">Produits</a></li>
    <li><a href="<?php echo e(route('services')); ?>" class="hover:text-gray-300">Services</a></li>
    <li><a href="<?php echo e(route('quisomme')); ?>" class="hover:text-gray-300">Qui sommes-nous</a></li>
</ul>
<?php /**PATH C:\xampp\htdocs\Cadriciel\41b-projetlaravel-tiagolp22\resto\resources\views/partials/nav.blade.php ENDPATH**/ ?>