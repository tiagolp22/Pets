produits

<?php /**PATH C:\xampp\htdocs\Cadriciel\41b-projetlaravel-tiagolp22\resto\resources\views/produits.blade.php ENDPATH**/ ?>