<?php $__env->startSection('title', 'INDEX'); ?>

<?php $__env->startSection('content'); ?>

   <main>
    <!-- Hero Banner -->
    <section class="">
        <img src="https://www.pexels.com/pt-br/foto/cachorro-piscando-preto-e-marrom-2023384/" alt="Hero Banner" class="">
    </section>

    <!-- Marcas -->
    <section class="py-8">
        <div class="container mx-auto">
            <h2 class="text-2xl font-semibold mb-4">Marques avec lesquelles nous travaillons</h2>
            <div class="grid grid-cols-6 md:grid-cols-6 gap-4">
                <!-- Logos das Marcas -->
                <div class="flex items-center justify-center">
                    <!-- Insira aqui as imagens das marcas -->
                    <img src="caminho/para/marca1.png" alt="Marca 1" class="h-16">
                </div>
                <div class="flex items-center justify-center">
                    <img src="caminho/para/marca2.png" alt="Marca 2" class="h-16">
                </div>
                <div class="flex items-center justify-center">
                    <img src="caminho/para/marca3.png" alt="Marca 3" class="h-16">
                </div>
                <div class="flex items-center justify-center">
                    <img src="caminho/para/marca3.png" alt="Marca 4" class="h-16">
                </div>
                <div class="flex items-center justify-center">
                    <img src="caminho/para/marca3.png" alt="Marca 5" class="h-16">
                </div>
                <div class="flex items-center justify-center">
                    <img src="caminho/para/marca3.png" alt="Marca 6" class="h-16">
                </div>
                <!-- Adicione mais divs para mais marcas conforme necessário -->
            </div>
        </div>
    </section>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cadriciel\41b-projetlaravel-tiagolp22\resto\resources\views/index.blade.php ENDPATH**/ ?>